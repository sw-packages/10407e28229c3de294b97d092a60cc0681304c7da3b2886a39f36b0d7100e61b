// SPDX-License-Identifier: Apache 2.0
// Copyright 2022 - Present, Syoyo Fujita.
//
// UsdLux implementations

#include "usdLux.hh"

namespace tinyusdz {

} // namespace tinyusdz


