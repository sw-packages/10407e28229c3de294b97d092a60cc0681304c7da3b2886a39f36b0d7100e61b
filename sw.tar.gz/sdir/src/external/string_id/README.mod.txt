Removed C++ excection.

EoL.
