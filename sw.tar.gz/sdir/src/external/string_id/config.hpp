// Copyright (C) 2014-2015 Jonathan Müller <jonathanmueller.dev@gmail.com>
// This file is subject to the license terms in the LICENSE file
// found in the top-level directory of this distribution.

// dummy header including the real config file from the CMake binary dir

#ifndef FOONATHAN_STRING_ID_CONFIG_HPP_INCLUDED
#define FOONATHAN_STRING_ID_CONFIG_HPP_INCLUDED

#include "config_impl.hpp"

#endif // FOONATHAN_STRING_ID_CONFIG_HPP_INCLUDED
