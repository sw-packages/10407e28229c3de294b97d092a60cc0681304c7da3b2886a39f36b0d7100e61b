Modification by Syoyo Fujita.

reports overflow error.
