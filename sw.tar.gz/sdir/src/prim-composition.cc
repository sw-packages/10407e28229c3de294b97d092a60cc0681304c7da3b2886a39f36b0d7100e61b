// SPDX-License-Identifier: Apache 2.0
// Copyright 2022-Present Light Transport Entertainment Inc.
#include "composition.hh"

namespace tinyusdz {
namespace prim {

namespace {

// Graphviz .dot wtier
class DotWriter
{
 public:
  DotWriter() = default;

};



} // namespace local

} // namespace prim
} // namespace tinyusdz


