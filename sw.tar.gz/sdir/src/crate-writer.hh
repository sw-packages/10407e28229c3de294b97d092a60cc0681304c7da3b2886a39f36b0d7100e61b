// SPDX-License-Identifier: MIT
// Copyright 2022 - Present, Syoyo Fujita.
//
// Crate(binary) writer
//
#pragma once

namespace tinyusdz {
namespace crate {


} // namespace crate
} // namespace tinyusdz

