#include "usdVox.hh"

#define OGT_VOX_IMPLEMENTATION
#include "external/ogt_vox.h"

namespace tinyusdz {
namespace usdVox {


} // namespace usdVox
} // namespace tinyusdz
